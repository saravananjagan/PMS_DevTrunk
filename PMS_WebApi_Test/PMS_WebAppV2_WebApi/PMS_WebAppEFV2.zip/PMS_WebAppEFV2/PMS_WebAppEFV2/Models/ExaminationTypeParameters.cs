﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS_WebAppEFV2.Models
{
    public class ExaminationTypeParameters
    {
        public List<string> ExaminationTypeIds;
    }
}