﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PMS_WebAppEFV2.Constants
{
    public static class CustomerConstants
    {
        public const string CustomerId = "F3A0C98F-2E41-47B9-9308-2169CA3728B1";
        public const string AddedById = "325253DD-D714-439E-9D3D-DE5785F96DA7";
    }
}